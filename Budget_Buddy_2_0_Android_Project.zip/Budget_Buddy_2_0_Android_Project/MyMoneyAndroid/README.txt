BUDGET BUDDY 2.0 – NATIVE ANDROID PROJECT (WITHOUT PERSONAL JSON DATA)

This is the complete native Java Android project. The personal transaction JSON
backup is intentionally NOT included.

FEATURES
- Home dashboard, Add, Insights and History screens
- Local SQLite database stored privately on the phone
- Add, edit and delete income/expense transactions
- Search, type filter and month filter
- JSON backup and restore using Android's file picker
- No INTERNET permission; no cloud service; offline operation

OPTIONAL FIRST-LAUNCH DATA IMPORT
The app checks for an optional file named initial_transactions.json in:
app/src/main/assets/initial_transactions.json
If you later add your JSON backup at that exact location before building the APK,
the app imports those records when its database is first created. If the file is
not present, the app starts with an empty database and you can restore your JSON
backup from the app's Settings/Backup & Restore screen.

JSON FORMAT
The file must be a JSON array. Each item should contain: date (YYYY-MM-DD),
type (earning or spending), name (text), and amount (number or null). The app
imports the data only when the local database is first created.

BUILD AN APK WITH GITHUB ACTIONS
1. Upload this ZIP to the repository root with the exact name expected by your
   workflow: Budget_Buddy_2_0_Android_Project.zip
2. Keep the workflow at .github/workflows/build-apk.yml.
3. Run the workflow from the Actions tab.
4. Download the APK artifact and extract app-debug.apk from its artifact ZIP.

BUILD LOCALLY IN ANDROID STUDIO
1. Extract this ZIP.
2. Open the MyMoneyAndroid folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).

IMPORTANT
- This environment does not have Android SDK/Gradle available, so this project
  has NOT been compiled or installed on a physical phone here.
- App data is removed when the app is uninstalled or its storage is cleared.
  Keep a JSON backup before uninstalling or reinstalling.
- Debug APKs built on different GitHub-hosted runners may be signed with
  different debug keys. Android may reject an update signed by a different key.
- The app does not request internet access.
