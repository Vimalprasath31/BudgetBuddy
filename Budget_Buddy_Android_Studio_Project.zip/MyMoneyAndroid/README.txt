MY MONEY – NATIVE ANDROID PROJECT

This is a native Java Android application project for Android Studio.

Included:
- Native Android screens (Home, Add, History)
- SQLite database stored privately in the app sandbox
- 51 imported transactions from the old tracker
- Income/spending totals and monthly overview
- Add, edit and delete transactions
- Search, type filter and month filter
- JSON backup and restore using Android's file picker
- No INTERNET permission; no cloud service; offline operation

BUILD AN APK:
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose File > Open and select the MyMoneyAndroid folder.
4. Let Android Studio sync Gradle and install Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be at:
   app/build/outputs/apk/debug/app-debug.apk
7. Copy the APK to your Android phone and install it. You may need to allow
   "Install unknown apps" for the file manager you use.

IMPORTANT:
- This chat environment does not have Android SDK/Gradle installed, so the APK
  has not been compiled or tested here. Android Studio performs the build.
- First launch imports the 51 records into the app's SQLite database.
- The amount for "Mobile Holder and Wired Earphone" is missing in the supplied
  history and remains blank until you edit that record and enter the amount.
- Android app data is removed if the app is uninstalled or its storage is cleared.
  Use History > Download backup before changing/resetting phones.
- This project does not request internet access.
