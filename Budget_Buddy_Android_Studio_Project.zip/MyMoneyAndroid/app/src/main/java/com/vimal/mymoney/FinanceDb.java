package com.vimal.mymoney;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class FinanceDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "mymoney_local.db";
    private static final int DB_VERSION = 1;
    private final Context context;

    public FinanceDb(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE transactions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "date TEXT NOT NULL," +
                "type TEXT NOT NULL," +
                "name TEXT NOT NULL," +
                "amount REAL)");
        seedInitialData(db);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    private void seedInitialData(SQLiteDatabase db) {
        try {
            InputStream in = context.getAssets().open("initial_transactions.json");
            byte[] bytes = new byte[in.available()];
            int read = in.read(bytes);
            in.close();
            JSONArray arr = new JSONArray(new String(bytes, StandardCharsets.UTF_8));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                ContentValues v = new ContentValues();
                v.put("date", o.getString("date"));
                v.put("type", o.getString("type"));
                v.put("name", o.getString("name"));
                if (o.isNull("amount")) v.putNull("amount");
                else v.put("amount", o.getDouble("amount"));
                db.insert("transactions", null, v);
            }
        } catch (Exception ignored) { }
    }

    public Cursor all(String search, String type, String month) {
        StringBuilder where = new StringBuilder("1=1");
        java.util.ArrayList<String> args = new java.util.ArrayList<>();
        if (search != null && !search.trim().isEmpty()) {
            where.append(" AND name LIKE ?");
            args.add("%" + search.trim() + "%");
        }
        if (type != null && !type.equals("all")) {
            if (type.equals("missing")) where.append(" AND amount IS NULL");
            else { where.append(" AND type=?"); args.add(type); }
        }
        if (month != null && !month.isEmpty()) {
            where.append(" AND date LIKE ?");
            args.add(month + "%");
        }
        return getReadableDatabase().rawQuery(
                "SELECT id,date,type,name,amount FROM transactions WHERE " + where +
                        " ORDER BY date DESC,id DESC", args.toArray(new String[0]));
    }

    public long add(String date, String type, String name, Double amount) {
        ContentValues v = new ContentValues();
        v.put("date", date); v.put("type", type); v.put("name", name);
        if (amount == null) v.putNull("amount"); else v.put("amount", amount);
        return getWritableDatabase().insert("transactions", null, v);
    }

    public void update(long id, String date, String type, String name, Double amount) {
        ContentValues v = new ContentValues();
        v.put("date", date); v.put("type", type); v.put("name", name);
        if (amount == null) v.putNull("amount"); else v.put("amount", amount);
        getWritableDatabase().update("transactions", v, "id=?", new String[]{String.valueOf(id)});
    }

    public void delete(long id) {
        getWritableDatabase().delete("transactions", "id=?", new String[]{String.valueOf(id)});
    }

    public double total(String type, String month) {
        Cursor c;
        if (month == null) c = getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type=?",
                new String[]{type});
        else c = getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type=? AND date LIKE ?",
                new String[]{type, month + "%"});
        double n = 0;
        if (c.moveToFirst()) n = c.getDouble(0);
        c.close();
        return n;
    }

    public int count() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM transactions", null);
        int n = c.moveToFirst() ? c.getInt(0) : 0;
        c.close();
        return n;
    }

    public JSONArray exportAll() {
        JSONArray a = new JSONArray();
        Cursor c = all("", "all", "");
        while (c.moveToNext()) {
            try {
                JSONObject o = new JSONObject();
                o.put("id", c.getLong(0));
                o.put("date", c.getString(1));
                o.put("type", c.getString(2));
                o.put("name", c.getString(3));
                if (c.isNull(4)) o.put("amount", JSONObject.NULL);
                else o.put("amount", c.getDouble(4));
                a.put(o);
            } catch (Exception ignored) { }
        }
        c.close();
        return a;
    }

    public void importReplace(JSONArray a) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("transactions", null, null);
            for (int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i);
                ContentValues v=new ContentValues();
                v.put("date",o.getString("date"));
                v.put("type",o.getString("type"));
                v.put("name",o.getString("name"));
                if(o.isNull("amount"))v.putNull("amount");else v.put("amount",o.getDouble("amount"));
                db.insert("transactions",null,v);
            }
            db.setTransactionSuccessful();
        } catch(Exception e) { throw new RuntimeException(e); }
        finally { db.endTransaction(); }
    }
}
