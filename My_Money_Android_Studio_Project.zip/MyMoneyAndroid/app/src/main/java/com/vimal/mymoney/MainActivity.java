package com.vimal.mymoney;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private FinanceDb db;
    private LinearLayout root, body, nav;
    private String page = "home";
    private String searchText = "", filterType = "all", filterMonth = "";
    private static final int CREATE_BACKUP = 501, OPEN_BACKUP = 502;
    private final int navy = Color.rgb(16,26,45), ink = Color.rgb(24,34,54);
    private final int green = Color.rgb(21,150,106), red = Color.rgb(220,85,85);
    private final int blue = Color.rgb(66,99,235), muted = Color.rgb(130,141,159);
    private final int bg = Color.rgb(244,246,251), line = Color.rgb(235,239,245);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new FinanceDb(this);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        showHome();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private String money(double n) {
        NumberFormat f = NumberFormat.getCurrencyInstance(new Locale("en","IN"));
        f.setMaximumFractionDigits(2);
        return f.format(n);
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable bgShape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void pad(View v, int all) { v.setPadding(dp(all),dp(all),dp(all),dp(all)); }
    private void start(String title, String subtitle) {
        root = column(); root.setBackgroundColor(bg);
        LinearLayout header = column(); header.setBackground(bgShape(navy,0));
        header.setPadding(dp(20),dp(18),dp(20),dp(22));
        header.addView(text("MY MONEY",11,0xFFB8C4D8,true));
        TextView h = text(title,23,Color.WHITE,true); h.setPadding(0,dp(4),0,dp(2)); header.addView(h);
        header.addView(text(subtitle,12,0xFFD0D9E8,false));
        root.addView(header);
        ScrollView scroll = new ScrollView(this); body = column(); body.setPadding(dp(14),dp(14),dp(14),dp(18));
        scroll.addView(body); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav = row(); nav.setBackgroundColor(Color.WHITE); nav.setPadding(dp(5),dp(8),dp(5),dp(8));
        addNav("⌂\nHome","home"); addNav("＋\nAdd","add"); addNav("☷\nHistory","history");
        root.addView(nav);
        setContentView(root);
    }
    private void addNav(String label, String target) {
        TextView b = text(label,12,page.equals(target)?blue:muted,true);
        b.setGravity(Gravity.CENTER); b.setPadding(0,dp(5),0,dp(5));
        nav.addView(b,new LinearLayout.LayoutParams(0,-2,1));
        b.setOnClickListener(v -> { page=target; if(target.equals("home"))showHome();else if(target.equals("add"))showAdd();else showHistory(); });
    }
    private LinearLayout card() {
        LinearLayout c = column(); c.setBackground(bgShape(Color.WHITE,18));
        c.setPadding(dp(16),dp(15),dp(16),dp(15));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(12);
        body.addView(c,p); return c;
    }
    private TextView button(String label, int color, int textColor) {
        TextView b=text(label,14,textColor,true); b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12),dp(13),dp(12),dp(13)); b.setBackground(bgShape(color,13)); return b;
    }
    private void addGap(LinearLayout l,int h){ View v=new View(this); l.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }

    private void showHome() {
        page="home"; start("Your money, simply managed","Private · Stored only on this phone");
        double in=db.total("earning",null), out=db.total("spending",null);
        LinearLayout c=card();
        c.addView(text("AVAILABLE BALANCE",11,muted,true));
        TextView bal=text(money(in-out),30,blue,true); bal.setPadding(0,dp(6),0,dp(14)); c.addView(bal);
        LinearLayout stats=row();
        LinearLayout left=column(),right=column();
        left.addView(text("↙ MONEY RECEIVED",10,muted,true)); left.addView(text(money(in),17,green,true));
        right.addView(text("↗ MONEY SPENT",10,muted,true)); right.addView(text(money(out),17,red,true));
        stats.addView(left,new LinearLayout.LayoutParams(0,-2,1)); stats.addView(right,new LinearLayout.LayoutParams(0,-2,1)); c.addView(stats);
        LinearLayout actions=row();
        TextView addIn=button("+  Received",0xFFE8F7F0,green), addOut=button("−  Spent",0xFFFFF0F0,red);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,-2,1); ap.rightMargin=dp(6);
        actions.addView(addIn,ap); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1); bp.leftMargin=dp(6); actions.addView(addOut,bp);
        body.addView(actions); addGap(body,12);
        addIn.setOnClickListener(v->{page="add";showForm("earning",null);});
        addOut.setOnClickListener(v->{page="add";showForm("spending",null);});
        LinearLayout m=card(); m.addView(text("THIS MONTH",14,ink,true));
        String month=new java.text.SimpleDateFormat("yyyy-MM",Locale.US).format(new java.util.Date());
        double mi=db.total("earning",month), mo=db.total("spending",month);
        addGap(m,8); m.addView(text("Collected   "+money(mi),13,green,true)); addGap(m,6);
        m.addView(text("Spent          "+money(mo),13,red,true)); addGap(m,6);
        m.addView(text("Monthly balance   "+money(mi-mo),13,blue,true));
        LinearLayout recent=card(); recent.addView(text("RECENT TRANSACTIONS",14,ink,true)); addGap(recent,6);
        Cursor cur=db.all("", "all", "");
        int n=0;
        while(cur.moveToNext() && n<5){ addTransactionRow(recent,cur); n++; }
        cur.close();
        if(n==0)recent.addView(text("No transactions yet.",13,muted,false));
        TextView all=button("View all transactions",0xFFEEF2FF,blue); recent.addView(all);
        all.setOnClickListener(v->{page="history";showHistory();});
        TextView privacy=text("Your records are saved in this app on this phone. Export a backup before changing or resetting your phone.",11,muted,false);
        privacy.setPadding(dp(4),dp(4),dp(4),dp(8)); body.addView(privacy);
    }

    private void showAdd() {
        page="add"; start("Add a transaction","Record money received or money spent");
        LinearLayout c=card();
        c.addView(text("What would you like to record?",14,ink,true)); addGap(c,10);
        TextView income=button("+  MONEY RECEIVED",0xFFE8F7F0,green);
        TextView spending=button("−  MONEY SPENT",0xFFFFF0F0,red);
        c.addView(income); addGap(c,10); c.addView(spending);
        income.setOnClickListener(v->showForm("earning",null));
        spending.setOnClickListener(v->showForm("spending",null));
    }

    private EditText edit(String hint, String value, int inputType) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setTextSize(15); e.setHint(hint);
        e.setInputType(inputType); e.setText(value==null?"":value);
        e.setPadding(dp(12),dp(9),dp(12),dp(9)); e.setBackground(bgShape(0xFFF5F7FA,11));
        return e;
    }
    private void showForm(String type, Cursor existing) {
        boolean isEdit=existing!=null;
        long id=isEdit?existing.getLong(0):-1;
        String date=isEdit?existing.getString(1):new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new java.util.Date());
        String name=isEdit?existing.getString(3):"";
        String amount=isEdit && !existing.isNull(4)?String.valueOf(existing.getDouble(4)):"";
        final String[] selectedType={isEdit?existing.getString(2):type};
        LinearLayout form=column(); form.setPadding(dp(4),dp(4),dp(4),dp(4));
        form.addView(text("Date (YYYY-MM-DD)",12,muted,true)); EditText dateE=edit("2026-10-30",date, android.text.InputType.TYPE_CLASS_DATETIME); form.addView(dateE);
        addGap(form,8); form.addView(text("Type",12,muted,true));
        Spinner spinner=new Spinner(this);
        String[] types={"Money received","Money spent"};
        spinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,types));
        spinner.setSelection(selectedType[0].equals("earning")?0:1);
        form.addView(spinner);
        addGap(form,8); form.addView(text("Description",12,muted,true)); EditText nameE=edit("e.g. Family, petrol, food",name,android.text.InputType.TYPE_CLASS_TEXT); form.addView(nameE);
        addGap(form,8); form.addView(text("Amount (₹)",12,muted,true)); EditText amountE=edit("Enter amount",amount,android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL); form.addView(amountE);
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long row){selectedType[0]=pos==0?"earning":"spending";}
            public void onNothingSelected(android.widget.AdapterView<?> p){}
        });
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(isEdit?"Edit transaction":"New transaction")
                .setView(form).setNegativeButton("Cancel",null).setPositiveButton(isEdit?"Save changes":"Save",null).create();
        dialog.setOnShowListener(x->dialog.getButton(-1).setOnClickListener(v->{
            String d=dateE.getText().toString().trim(), nm=nameE.getText().toString().trim(), a=amountE.getText().toString().trim();
            if(!d.matches("\\d{4}-\\d{2}-\\d{2}")||nm.isEmpty()||a.isEmpty()){Toast.makeText(this,"Enter a valid date, description and amount",Toast.LENGTH_SHORT).show();return;}
            try{
                double val=Double.parseDouble(a); if(val<=0)throw new Exception();
                if(isEdit)db.update(id,d,selectedType[0],nm,val);else db.add(d,selectedType[0],nm,val);
                dialog.dismiss();showHome();Toast.makeText(this,isEdit?"Transaction updated":"Transaction saved",Toast.LENGTH_SHORT).show();
            }catch(Exception ex){Toast.makeText(this,"Enter a valid amount",Toast.LENGTH_SHORT).show();}
        }));
        dialog.show();
    }

    private void showHistory() {
        page="history"; start("Transaction history","Search, edit or delete your records");
        LinearLayout tools=card();
        EditText search=edit("Search description",searchText,android.text.InputType.TYPE_CLASS_TEXT); tools.addView(search);
        Spinner filter=new Spinner(this);
        String[] options={"All transactions","Money received","Money spent","Missing amount"};
        filter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,options));
        filter.setSelection(filterType.equals("earning")?1:filterType.equals("spending")?2:filterType.equals("missing")?3:0);
        tools.addView(filter);
        EditText month=edit("Optional month: YYYY-MM",filterMonth,android.text.InputType.TYPE_CLASS_DATETIME); tools.addView(month);
        LinearLayout list=card(); TextView count=text(db.count()+" records",12,muted,true); list.addView(count);
        Runnable refresh=()->{
            searchText=search.getText().toString();
            filterType=filter.getSelectedItemPosition()==1?"earning":filter.getSelectedItemPosition()==2?"spending":filter.getSelectedItemPosition()==3?"missing":"all";
            filterMonth=month.getText().toString().trim();
            list.removeViews(1,Math.max(0,list.getChildCount()-1));
            Cursor c=db.all(searchText,filterType,filterMonth);
            int num=0;while(c.moveToNext()){addTransactionRow(list,c);num++;}
            c.close();count.setText(num+" matching records");
            if(num==0)list.addView(text("No transactions found.",13,muted,false));
        };
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}public void afterTextChanged(Editable e){}});
        filter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){refresh.run();}public void onNothingSelected(android.widget.AdapterView<?> p){}});
        month.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}public void afterTextChanged(Editable e){}});
        refresh.run();
        LinearLayout backup=card(); backup.addView(text("BACKUP & RESTORE",14,ink,true)); addGap(backup,8);
        TextView exp=button("Download backup (JSON)",0xFFEEF2FF,blue); backup.addView(exp); addGap(backup,8);
        TextView imp=button("Restore backup (JSON)",0xFFEEF2FF,blue); backup.addView(imp);
        exp.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"my-money-backup.json");startActivityForResult(i,CREATE_BACKUP);});
        imp.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,OPEN_BACKUP);});
        TextView note=text("Keep a backup before changing or resetting your phone. Your database is private to this app and is not uploaded anywhere.",11,muted,false); note.setPadding(dp(4),dp(4),dp(4),dp(4)); body.addView(note);
    }

    private void addTransactionRow(LinearLayout parent, Cursor c) {
        long id=c.getLong(0); String date=c.getString(1), type=c.getString(2), name=c.getString(3);
        boolean income=type.equals("earning"), missing=c.isNull(4);
        LinearLayout r=row(); r.setPadding(0,dp(10),0,dp(10));
        LinearLayout info=column(); info.addView(text(name,14,ink,true)); info.addView(text(date+" · "+(income?"Received":"Spent"),11,muted,false));
        r.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout right=column(); right.setGravity(Gravity.RIGHT);
        right.addView(text(missing?"Amount missing":(income?"+":"−")+money(c.getDouble(4)),13,missing?muted:(income?green:red),true));
        LinearLayout buttons=row();
        TextView edit=text("Edit",11,blue,true); edit.setPadding(dp(5),dp(5),dp(8),dp(3));
        TextView del=text("Delete",11,red,true); del.setPadding(dp(5),dp(5),dp(5),dp(3));
        buttons.addView(edit);buttons.addView(del);right.addView(buttons);r.addView(right);
        parent.addView(r); View divider=new View(this);divider.setBackgroundColor(line);parent.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        edit.setOnClickListener(v->{Cursor one=db.getReadableDatabase().rawQuery("SELECT id,date,type,name,amount FROM transactions WHERE id=?",new String[]{String.valueOf(id)});if(one.moveToFirst())showForm(one.getString(2),one);one.close();});
        del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Delete transaction?")
                .setMessage("This record will be removed from this phone.")
                .setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{db.delete(id);if(page.equals("history"))showHistory();else showHome();}).show());
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try {
            if(requestCode==CREATE_BACKUP){
                OutputStream out=getContentResolver().openOutputStream(uri);
                out.write(db.exportAll().toString(2).getBytes("UTF-8"));out.close();
                Toast.makeText(this,"Backup saved",Toast.LENGTH_LONG).show();
            } else if(requestCode==OPEN_BACKUP){
                InputStream in=getContentResolver().openInputStream(uri);
                BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));
                StringBuilder s=new StringBuilder();String line;while((line=br.readLine())!=null)s.append(line);br.close();
                JSONArray a=new JSONArray(s.toString());
                new AlertDialog.Builder(this).setTitle("Restore backup?")
                        .setMessage("This replaces the current "+db.count()+" records with "+a.length()+" backup records.")
                        .setNegativeButton("Cancel",null).setPositiveButton("Restore",(d,w)->{
                            try{db.importReplace(a);showHome();Toast.makeText(this,"Backup restored",Toast.LENGTH_LONG).show();}
                            catch(Exception e){Toast.makeText(this,"Could not restore this file",Toast.LENGTH_LONG).show();}
                        }).show();
            }
        } catch(Exception e){Toast.makeText(this,"File operation failed",Toast.LENGTH_LONG).show();}
    }

    @Override public void onBackPressed() {
        if(!page.equals("home")){showHome();}else super.onBackPressed();
    }
}
